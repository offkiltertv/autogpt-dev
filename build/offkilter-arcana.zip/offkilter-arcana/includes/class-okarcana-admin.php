<?php

if (!defined('ABSPATH')) {
    exit;
}

class OKArcana_Admin
{
    public static function init()
    {
        add_action('admin_menu', array(__CLASS__, 'register_menu'));
        add_action('admin_post_okarcana_save_settings', array(__CLASS__, 'handle_save_settings'));
        add_action('admin_post_okarcana_run_signals_backfill', array(__CLASS__, 'handle_run_signals_backfill'));

        // Legacy import/scheduler actions are retained for backward compatibility.
        add_action('admin_post_okarcana_import_manual', array(__CLASS__, 'handle_import_manual'));
        add_action('admin_post_okarcana_import_csv', array(__CLASS__, 'handle_import_csv'));
        add_action('admin_post_okarcana_import_takeout', array(__CLASS__, 'handle_import_takeout'));
        add_action('admin_post_okarcana_run_scheduler', array(__CLASS__, 'handle_run_scheduler'));
    }

    public static function register_menu()
    {
        add_menu_page(
            __('Arcana', 'offkilter-arcana'),
            __('Arcana', 'offkilter-arcana'),
            'manage_options',
            'okarcana',
            array(__CLASS__, 'render_admin_page'),
            'dashicons-art',
            56
        );
    }

    public static function render_admin_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'offkilter-arcana'));
        }

        $settings = OKArcana_Settings::all();
        $mapping_lines = OKArcana_Settings::render_mapping_lines($settings['playlist_mappings']);
        $signals_summary = OKArcana_Signals::get_summary_counts();

        global $wpdb;
        $table = OKArcana_DB::table_name();
        $rows = $wpdb->get_results("SELECT id, post_id, source_name, youtube_id, queue_state, imported_at, scheduled_for, published_at FROM {$table} ORDER BY id DESC LIMIT 50", ARRAY_A);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Arcana', 'offkilter-arcana'); ?></h1>

            <?php if (!empty($_GET['okarcana_msg'])) : ?>
                <div class="notice notice-success"><p><?php echo esc_html(wp_unslash($_GET['okarcana_msg'])); ?></p></div>
            <?php endif; ?>

            <h2><?php esc_html_e('Arcana Settings', 'offkilter-arcana'); ?></h2>

            <h3><?php esc_html_e('Signals Classification Status', 'offkilter-arcana'); ?></h3>
            <table class="widefat striped" style="max-width:760px;margin-bottom:1rem;">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Imported Content', 'offkilter-arcana'); ?></th>
                        <th><?php esc_html_e('Signals (0-90s)', 'offkilter-arcana'); ?></th>
                        <th><?php esc_html_e('Watch (90+s)', 'offkilter-arcana'); ?></th>
                        <th><?php esc_html_e('Unknown Duration', 'offkilter-arcana'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo (int) $signals_summary['total']; ?></td>
                        <td><?php echo (int) $signals_summary['signals']; ?></td>
                        <td><?php echo (int) $signals_summary['videos']; ?></td>
                        <td><?php echo (int) $signals_summary['unknown']; ?></td>
                    </tr>
                </tbody>
            </table>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:1.5rem;">
                <?php wp_nonce_field('okarcana_run_signals_backfill'); ?>
                <input type="hidden" name="action" value="okarcana_run_signals_backfill" />
                <button class="button button-secondary" type="submit"><?php esc_html_e('Run Signals Backfill Batch', 'offkilter-arcana'); ?></button>
                <p class="description"><?php esc_html_e('Classifies imported content that does not yet have Signals metadata.', 'offkilter-arcana'); ?></p>
            </form>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('okarcana_save_settings'); ?>
                <input type="hidden" name="action" value="okarcana_save_settings" />

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Disclaimer Injection', 'offkilter-arcana'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_disclaimer" value="1" <?php checked(!empty($settings['enable_disclaimer'])); ?> />
                                <?php esc_html_e('Append Arcana disclaimer to arcana_entry content.', 'offkilter-arcana'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('wpForo Integration', 'offkilter-arcana'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_wpforo" value="1" <?php checked(!empty($settings['enable_wpforo'])); ?> />
                                <?php esc_html_e('Create a wpForo topic when Arcana entries publish.', 'offkilter-arcana'); ?>
                            </label>
                            <p>
                                <label>
                                    <?php esc_html_e('wpForo Forum ID', 'offkilter-arcana'); ?>
                                    <input type="number" name="wpforo_forum_id" min="1" value="<?php echo esc_attr((int) $settings['wpforo_forum_id']); ?>" class="small-text" />
                                </label>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Related Arcana Count', 'offkilter-arcana'); ?></th>
                        <td>
                            <input type="number" name="related_count" min="1" max="20" value="<?php echo esc_attr((int) $settings['related_count']); ?>" class="small-text" />
                            <p class="description"><?php esc_html_e('Number of related Arcana IDs to store per entry.', 'offkilter-arcana'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Default Arcana Tags', 'offkilter-arcana'); ?></th>
                        <td>
                            <textarea name="default_tags" rows="3" cols="80" placeholder="Destiny,Choice,Journey"><?php echo esc_textarea((string) $settings['default_tags']); ?></textarea>
                            <p class="description"><?php esc_html_e('Comma or newline separated tags applied to all Arcana entries.', 'offkilter-arcana'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Signals Classification', 'offkilter-arcana'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_signals_classification" value="1" <?php checked(!empty($settings['enable_signals_classification'])); ?> />
                                <?php esc_html_e('Automatically classify imported content as Signal (≤90s) or Watch (>90s).', 'offkilter-arcana'); ?>
                            </label>
                            <p>
                                <label>
                                    <?php esc_html_e('Signal Threshold (seconds)', 'offkilter-arcana'); ?>
                                    <input type="number" min="10" max="3600" class="small-text" name="signals_threshold_seconds" value="<?php echo esc_attr((int) $settings['signals_threshold_seconds']); ?>" />
                                </label>
                            </p>
                            <p>
                                <label>
                                    <?php esc_html_e('Backfill Batch Size', 'offkilter-arcana'); ?>
                                    <input type="number" min="1" max="500" class="small-text" name="signals_backfill_batch_size" value="<?php echo esc_attr((int) $settings['signals_backfill_batch_size']); ?>" />
                                </label>
                            </p>
                            <p>
                                <label for="signals_duration_meta_keys"><?php esc_html_e('Duration Meta Keys (comma/newline separated)', 'offkilter-arcana'); ?></label><br>
                                <textarea id="signals_duration_meta_keys" name="signals_duration_meta_keys" rows="3" cols="80" placeholder="beeteam368_video_duration"><?php echo esc_textarea((string) $settings['signals_duration_meta_keys']); ?></textarea>
                            </p>
                            <p class="description">
                                <?php esc_html_e('Default shortcodes: [oktv_signals_latest] and [oktv_arcana_signals_latest].', 'offkilter-arcana'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Playlist to Taxonomy Mapping', 'offkilter-arcana'); ?></th>
                        <td>
                            <textarea name="playlist_mapping_lines" rows="8" cols="100"><?php echo esc_textarea($mapping_lines); ?></textarea>
                            <p class="description"><?php esc_html_e('One mapping per line: playlist_match|category1,category2|tag1,tag2', 'offkilter-arcana'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Watch Experience', 'offkilter-arcana'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_watch_next_append" value="1" <?php checked(!empty($settings['enable_watch_next_append'])); ?> />
                                <?php esc_html_e('Append "Watch Next" recommendations and the discussion slot to public single-video pages.', 'offkilter-arcana'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Launch Curation', 'offkilter-arcana'); ?></th>
                        <td>
                            <p>
                                <label for="featured_creator_ids"><?php esc_html_e('Featured Creator User IDs', 'offkilter-arcana'); ?></label><br>
                                <input type="text" id="featured_creator_ids" name="featured_creator_ids" class="regular-text" value="<?php echo esc_attr((string) $settings['featured_creator_ids']); ?>" placeholder="87,123,124" />
                            </p>
                            <p class="description"><?php esc_html_e('Comma-separated user IDs of the launch lineup. When set, these are used (in order) for "Creators to Watch" and "Creators on Pulse" instead of the top-by-post-count fallback.', 'offkilter-arcana'); ?></p>
                            <p>
                                <label for="deprecated_creator_user_ids"><?php esc_html_e('Deprecated Creator User IDs', 'offkilter-arcana'); ?></label><br>
                                <input type="text" id="deprecated_creator_user_ids" name="deprecated_creator_user_ids" class="regular-text" value="<?php echo esc_attr((string) $settings['deprecated_creator_user_ids']); ?>" placeholder="" />
                            </p>
                            <p class="description"><?php esc_html_e('Comma-separated legacy author user IDs to exclude from the discovery/pulse fallback when no featured lineup is set.', 'offkilter-arcana'); ?></p>
                            <p>
                                <label for="deprecated_creator_term_ids"><?php esc_html_e('Deprecated Creator Term IDs', 'offkilter-arcana'); ?></label><br>
                                <input type="text" id="deprecated_creator_term_ids" name="deprecated_creator_term_ids" class="regular-text" value="<?php echo esc_attr((string) $settings['deprecated_creator_term_ids']); ?>" placeholder="2055" />
                            </p>
                            <p class="description"><?php esc_html_e('Comma-separated creator term IDs (vidmov_video_category, e.g. 2055 for @lipps). Imported posts tagged to these terms are held (never auto-published) by the scheduler.', 'offkilter-arcana'); ?></p>
                        </td>
                    </tr>
                </table>

                <p><button class="button button-primary" type="submit"><?php esc_html_e('Save Arcana Settings', 'offkilter-arcana'); ?></button></p>
            </form>

            <hr>
            <h2><?php esc_html_e('Publishing Queue (Legacy)', 'offkilter-arcana'); ?></h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:1rem;">
                <?php wp_nonce_field('okarcana_run_scheduler'); ?>
                <input type="hidden" name="action" value="okarcana_run_scheduler" />
                <button class="button button-secondary" type="submit"><?php esc_html_e('Run Scheduler Now', 'offkilter-arcana'); ?></button>
            </form>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Content</th>
                        <th>Source</th>
                        <th>YouTube ID</th>
                        <th>State</th>
                        <th>Imported</th>
                        <th>Scheduled</th>
                        <th>Published</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!empty($rows)) : foreach ($rows as $row) : ?>
                    <tr>
                        <td><?php echo (int) $row['id']; ?></td>
                        <td>
                            <?php
                            $edit = !empty($row['post_id']) ? get_edit_post_link((int) $row['post_id']) : '';
                            if ($edit) {
                                echo '<a href="' . esc_url($edit) . '">#' . (int) $row['post_id'] . '</a>';
                            } else {
                                echo '&mdash;';
                            }
                            ?>
                        </td>
                        <td><?php echo esc_html($row['source_name']); ?></td>
                        <td><?php echo esc_html($row['youtube_id']); ?></td>
                        <td><?php echo esc_html($row['queue_state']); ?></td>
                        <td><?php echo esc_html($row['imported_at']); ?></td>
                        <td><?php echo esc_html($row['scheduled_for']); ?></td>
                        <td><?php echo esc_html($row['published_at']); ?></td>
                    </tr>
                <?php endforeach; else : ?>
                    <tr><td colspan="8">No queue records yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function handle_save_settings()
    {
        self::assert_admin_nonce('okarcana_save_settings');

        $mappings_raw = isset($_POST['playlist_mapping_lines']) ? wp_unslash($_POST['playlist_mapping_lines']) : '';
        $settings = array(
            'enable_disclaimer' => isset($_POST['enable_disclaimer']) ? 1 : 0,
            'enable_wpforo' => isset($_POST['enable_wpforo']) ? 1 : 0,
            'wpforo_forum_id' => isset($_POST['wpforo_forum_id']) ? (int) $_POST['wpforo_forum_id'] : 1,
            'related_count' => isset($_POST['related_count']) ? (int) $_POST['related_count'] : 5,
            'default_tags' => isset($_POST['default_tags']) ? wp_unslash($_POST['default_tags']) : '',
            'enable_signals_classification' => isset($_POST['enable_signals_classification']) ? 1 : 0,
            'signals_threshold_seconds' => isset($_POST['signals_threshold_seconds']) ? (int) $_POST['signals_threshold_seconds'] : 90,
            'signals_backfill_batch_size' => isset($_POST['signals_backfill_batch_size']) ? (int) $_POST['signals_backfill_batch_size'] : 75,
            'signals_duration_meta_keys' => isset($_POST['signals_duration_meta_keys']) ? wp_unslash($_POST['signals_duration_meta_keys']) : '',
            'enable_watch_next_append' => isset($_POST['enable_watch_next_append']) ? 1 : 0,
            'featured_creator_ids' => isset($_POST['featured_creator_ids']) ? wp_unslash($_POST['featured_creator_ids']) : '',
            'deprecated_creator_user_ids' => isset($_POST['deprecated_creator_user_ids']) ? wp_unslash($_POST['deprecated_creator_user_ids']) : '',
            'deprecated_creator_term_ids' => isset($_POST['deprecated_creator_term_ids']) ? wp_unslash($_POST['deprecated_creator_term_ids']) : '',
            'playlist_mappings' => OKArcana_Settings::parse_mapping_lines($mappings_raw),
        );

        OKArcana_Settings::update($settings);
        self::redirect_with_message('Arcana settings saved.');
    }

    public static function handle_import_manual()
    {
        self::assert_admin_nonce('okarcana_import_manual');

        $source_name = isset($_POST['source_name']) ? sanitize_text_field(wp_unslash($_POST['source_name'])) : 'Manual Import';
        $urls = isset($_POST['urls']) ? wp_unslash($_POST['urls']) : '';

        $res = OKArcana_Importer::import_manual_urls($urls, $source_name, 'manual');
        self::redirect_with_result($res);
    }

    public static function handle_import_csv()
    {
        self::assert_admin_nonce('okarcana_import_csv');

        if (empty($_FILES['csv_file']['tmp_name'])) {
            self::redirect_with_message('No CSV file uploaded.');
        }

        $res = OKArcana_Importer::import_csv_file($_FILES['csv_file']['tmp_name']);
        self::redirect_with_result($res);
    }

    public static function handle_import_takeout()
    {
        self::assert_admin_nonce('okarcana_import_takeout');

        if (empty($_FILES['takeout_file']['tmp_name'])) {
            self::redirect_with_message('No Takeout file uploaded.');
        }

        $res = OKArcana_Importer::import_takeout_file($_FILES['takeout_file']['tmp_name']);
        self::redirect_with_result($res);
    }

    public static function handle_run_scheduler()
    {
        self::assert_admin_nonce('okarcana_run_scheduler');
        OKArcana_Scheduler::run_scheduler();
        self::redirect_with_message('Scheduler executed.');
    }

    public static function handle_run_signals_backfill()
    {
        self::assert_admin_nonce('okarcana_run_signals_backfill');
        $processed = (int) OKArcana_Signals::run_backfill_batch();
        self::redirect_with_message(sprintf('Signals backfill processed %d posts.', $processed));
    }

    private static function assert_admin_nonce($action)
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'offkilter-arcana'));
        }

        check_admin_referer($action);
    }

    private static function redirect_with_result($result)
    {
        $msg = sprintf(
            'Import complete: created=%d, skipped=%d, errors=%d',
            (int) $result['created'],
            (int) $result['skipped'],
            isset($result['errors']) ? count((array) $result['errors']) : 0
        );

        self::redirect_with_message($msg);
    }

    private static function redirect_with_message($message)
    {
        $url = add_query_arg(array('page' => 'okarcana', 'okarcana_msg' => rawurlencode($message)), admin_url('admin.php'));
        wp_safe_redirect($url);
        exit;
    }
}
